package co.edu.uco.victusresidencias.victusresidencias_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VictusresidenciasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VictusresidenciasApiApplication.class, args);
	}

}
